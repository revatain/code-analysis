#ex3.py

score = int(input("점수를 입력하세요 : "))

if score >=90:
    print("A")
elif score >= 80:
    print("B")
elif score >= 70:
    print("C")
elif score >= 80:
    print("D")
else:
    print("F")

print("학점입니다")