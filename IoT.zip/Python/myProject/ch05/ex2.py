#ex2.py

a = 75

if a > 50:
    if a < 100:
        print("50보다 크고 100보다 작군요")
    else:
        print("와~100보다 크군요")
else:
    print("에고~50보다 작군요")
