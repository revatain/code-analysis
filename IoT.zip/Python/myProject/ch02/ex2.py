# ex2.py

a = int(input("첫번째 숫자를 입력하세요 : "))
b = int(input("두번째 숫자를 입력하세요 : "))
result = a + b
print(a , " + " ,b ,  " = " , result)
result = a - b
print(a , " - " ,b ,  " = " , result)
result = a * b
print(a , " * " ,b ,  " = " , result)
result = a / b
print(a , " / " ,b ,  " = " , result)