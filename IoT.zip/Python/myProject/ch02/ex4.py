#ex4.py

import turtle

t = turtle.Turtle()
t.shape('turtle')
t.color('blue')

t.forward(200)
t.right(90)
t.forward(200)
t.right(90)
t.forward(200)
t.right(90)
t.forward(200)
t.right(90)

turtle.done()