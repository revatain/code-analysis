#ex1.py

a = 100
b = 50
result = a + b
print(a , " + " ,b ,  " = " , result)
result = a - b
print(a , " - " ,b ,  " = " , result)
result = a * b
print(a , " * " ,b ,  " = " , result)
result = a / b
print(a , " / " ,b ,  " = " , result)

