SELECT * FROM tblmember WHERE id = 1
SELECT*FROM tblEx2;CREATE TABLE `tblZipcode` (
  `zipcode` char(7) NOT NULL,
  `area1` char(10) DEFAULT NULL,
  `area2` char(20) DEFAULT NULL,
  `area3` char(40) DEFAULT NULL,
  `area4` char(20) DEFAULT NULL
)